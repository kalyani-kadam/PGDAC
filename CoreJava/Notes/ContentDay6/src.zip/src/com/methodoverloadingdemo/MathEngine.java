package com.methodoverloadingdemo;

public class MathEngine {
	
	public static int add(int num1,int num2)
	{
		return num1+num2;
	}
	
	public static String add(String str1,String str2)
	{
		return str1+str2;
	}

}
