package com.interfacedemo;

public interface IPrintable {

	void print();
}
