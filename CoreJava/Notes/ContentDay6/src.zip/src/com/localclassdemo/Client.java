package com.localclassdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer outobj=new Outer();
		outobj.outerMethod(78);
	}

}
