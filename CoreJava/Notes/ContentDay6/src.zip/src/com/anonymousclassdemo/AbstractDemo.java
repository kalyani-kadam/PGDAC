package com.anonymousclassdemo;

public abstract class AbstractDemo {
	abstract void show();
}
