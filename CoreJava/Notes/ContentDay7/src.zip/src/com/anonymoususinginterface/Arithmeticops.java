package com.anonymoususinginterface;

public interface Arithmeticops {
	void calculate(int num1,int num2);
}
