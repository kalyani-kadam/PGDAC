package com.anonymoususinginterface;

public class Client {
	
	public static void main(String[] args)
	{
	
		//anonymous class traditional syntax
		/*Arithmeticops a1=new Arithmeticops() {			
			@Override
			public void calculate(int num1, int num2) {
				// TODO Auto-generated method stub
				System.out.println("the addition is "+(num1+num2));
			}
		};
		a1.calculate(12, 4);
		*/
		/*Arithmeticops a2=new Arithmeticops() {			
		@Override
		public void calculate(int num1, int num2) {
			// TODO Auto-generated method stub
			System.out.println("the subtraction is "+(num1-num2));
		}
	};
	a2.calculate(12, 4);*/
		
		//anonymous class lambda expression syntax
		Arithmeticops a1=(num1,num2)->{System.out.println("the addition is "+(num1+num2));};
		a1.calculate(12,4);
		
		Arithmeticops a2=(num1,num2)->{System.out.println("the subtraction is "+(num1-num2));};
		a2.calculate(12,4);
		
		
	}
	

}
