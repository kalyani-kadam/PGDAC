package com.customexceptiondemo;

public class Account {
	
	private double bal;
	
	public Account(double bal)
	{
		this.bal=bal;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "balance is-"+this.bal;
	}
	
	public void deposit(double amt)
	{
		this.bal+=amt;
	}
	public void withdraw(double amt) throws AccountException
	{
		if(amt>this.bal)
		{
			throw new AccountException("Insufficient balance!!!");
		}
		this.bal-=amt;
	}	
	
	

}
