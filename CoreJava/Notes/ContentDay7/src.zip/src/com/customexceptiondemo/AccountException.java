package com.customexceptiondemo;

public class AccountException extends Exception {
	
	public AccountException(String errmsg)
	{
		super(errmsg);
	}

}
