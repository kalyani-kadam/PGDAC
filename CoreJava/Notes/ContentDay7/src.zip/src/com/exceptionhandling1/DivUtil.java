package com.exceptionhandling1;

public class DivUtil {

	public static int division(int numerator,int denominator) throws ArithmeticException
	{
		int result=numerator/denominator;
		return result;
	}

}
