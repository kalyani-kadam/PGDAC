package com.exceptionhandling1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		try
		{
			// TODO Auto-generated method stub
			int numerator,denominator,result;
			Scanner in=new Scanner(System.in);		
			System.out.println("enter numerator:");
			numerator=in.nextInt();
			System.out.println("enter denominator:");
			denominator=in.nextInt();	
			result=DivUtil.division(numerator, denominator);
			System.out.println("the result is "+result);
		}
		catch(ArithmeticException ex)
		{
			System.out.println(ex.getMessage());
		}
		catch(InputMismatchException ex)
		{
			System.out.println("Invalid input");
		}
		catch(Exception ex)
		{
			System.out.println("Some other err");
		}
		finally
		{
			System.out.println("termination activities performed in finally");
		}



		/* 1st iteration
		try
		{
			int numerator,denominator,result;
			Scanner in=new Scanner(System.in);		
			System.out.println("enter numerator:");
			numerator=in.nextInt();
			System.out.println("enter denominator:");
			denominator=in.nextInt();	
			result=numerator/denominator;		
			System.out.println("the result is "+result);
		}
		catch(ArithmeticException ex)
		{
			System.out.println(ex.getMessage());
		}
		catch(InputMismatchException ex)
		{
			System.out.println("Invalid input");
		}
		catch(Exception ex)
		{
			System.out.println("Some other err");
		}
		finally
		{
			System.out.println("termination activities performed in finally");
		}*/
	}

}
