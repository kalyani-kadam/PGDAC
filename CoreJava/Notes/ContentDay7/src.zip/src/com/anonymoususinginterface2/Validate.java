package com.anonymoususinginterface2;

public interface Validate {

	boolean check(int num);
}
