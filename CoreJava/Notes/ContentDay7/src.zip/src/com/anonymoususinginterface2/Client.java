package com.anonymoususinginterface2;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=10;
		
		Validate v1= (num)-> {
			if(num%2==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		};
		boolean result=v1.check(x);
		System.out.println(result);
		
		
	}

}
