package com.anonymoususingabstractclassdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//anonymous class is define to perform addition and instantiated in single line
		Arithmeticops a1=new Arithmeticops() {			
			@Override
			public void calculate(int num1, int num2) {
				// TODO Auto-generated method stub
				System.out.println("the addition is "+(num1+num2));
			}

			@Override
			public void test() {
				// TODO Auto-generated method stub
				System.out.println("the test of addition a1");
			}
		};
		a1.calculate(12,4); //invoke the calculate() on anonymous class object
		a1.test();
		a1=new Arithmeticops() {			
			@Override
			public void calculate(int num1, int num2) {
				// TODO Auto-generated method stub
				System.out.println("the subtracttion is "+(num1-num2));
			}
			@Override
			public void test() {
				// TODO Auto-generated method stub
				System.out.println("the test of minus a1");
			}
		};
		a1.calculate(12,3);
		a1.test();
		
		
		Arithmeticops a2=new Arithmeticops() {
			
			@Override
			public void test() {
				// TODO Auto-generated method stub
				System.out.println("in test of mul a2");
			}
			
			@Override
			public void calculate(int num1, int num2) {
				// TODO Auto-generated method stub
				System.out.println("the multiplicaiton is "+(num1*num2));
			}
		};
		a2.test();
		a2.calculate(12,2);
	}

}
