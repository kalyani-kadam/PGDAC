package com.anonymoususingabstractclassdemo;

public abstract class Arithmeticops {

	public abstract void calculate(int num1,int num2);
	public abstract void test();
}
