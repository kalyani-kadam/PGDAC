package com.app.service;

import com.app.entity.Patient;

public interface PatientService {
	Patient addNewPatient(Patient patient);
}
